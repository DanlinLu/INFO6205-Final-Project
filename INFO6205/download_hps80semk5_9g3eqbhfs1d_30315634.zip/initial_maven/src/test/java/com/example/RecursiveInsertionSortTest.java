package com.example;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class RecursiveInsertionSortTest {
    @Test
    public void RISTest1(){
        RecursiveInsertionSort ris = new RecursiveInsertionSort();
        int[] arr = new int[]{37, 23, 0, 17, 12, 72, 31, 46, 100, 88, 54};
        int[] output = new int[]{0,12,17,23,31,37,46,54,72,88,100};
        int[] temp = ris.insertionSort(arr, 11);
        List<Integer> list = new ArrayList<>();
        List<Integer> res = new ArrayList<>();
        for(int n : temp) {
            list.add(n);
        }
        for(int n : output) {
            res.add(n);
        }
        Assert.assertEquals(list, res);
    }

    @Test
    public void RISTest2(){
        RecursiveInsertionSort ris = new RecursiveInsertionSort();
        int[] arr = new int[]{100, 90, 80, 70, 60, 50, 40, 30, 20, 10};
        int[] output = new int[]{10,20,30,40,50,60,70,80,90,100};
        int[] temp = ris.insertionSort(arr, 10);
        List<Integer> list = new ArrayList<>();
        List<Integer> res = new ArrayList<>();
        for(int n : temp) {
            list.add(n);
        }
        for(int n : output) {
            res.add(n);
        }
        Assert.assertEquals(list, res);
    }

    @Test
    public void RISTest3(){
        RecursiveInsertionSort ris = new RecursiveInsertionSort();
        int[] arr = new int[]{45, 98, 17, 34, 63};
        int[] output = new int[]{17,34,45,63,98};
        int[] temp = ris.insertionSort(arr, 5);
        List<Integer> list = new ArrayList<>();
        List<Integer> res = new ArrayList<>();
        for(int n : temp) {
            list.add(n);
        }
        for(int n : output) {
            res.add(n);
        }
        Assert.assertEquals(list, res);
    }

    @Test
    public void RISTest4(){
        RecursiveInsertionSort ris = new RecursiveInsertionSort();
        int[] arr = new int[]{2, 15, 27, 33, 101, 253, 377, 999};
        int[] output = new int[]{2, 15, 27, 33, 101, 253, 377, 999};
        int[] temp = ris.insertionSort(arr, 8);
        List<Integer> list = new ArrayList<>();
        List<Integer> res = new ArrayList<>();
        for(int n : temp) {
            list.add(n);
        }
        for(int n : output) {
            res.add(n);
        }
        Assert.assertEquals(list, res);
    }

    @Test
    public void RISTest5(){
        RecursiveInsertionSort ris = new RecursiveInsertionSort();
        int[] arr = new int[]{1, 7, 25, 19, 32, 27};
        int[] output = new int[]{1, 7, 19, 25, 27, 32};
        int[] temp = ris.insertionSort(arr, 6);
        List<Integer> list = new ArrayList<>();
        List<Integer> res = new ArrayList<>();
        for(int n : temp) {
            list.add(n);
        }
        for(int n : output) {
            res.add(n);
        }
        Assert.assertEquals(list, res);
    }
    
    @Test
    public void RISTest6(){
        RecursiveInsertionSort ris = new RecursiveInsertionSort();
        int[] arr = new int[]{};
        int[] output = new int[]{};
        int[] temp = ris.insertionSort(arr, 0);
        List<Integer> list = new ArrayList<>();
        List<Integer> res = new ArrayList<>();
        for(int n : temp) {
            list.add(n);
        }
        for(int n : output) {
            res.add(n);
        }
        Assert.assertEquals(list, res);
    }
    
       @Test
    public void RISTest7(){
        RecursiveInsertionSort ris = new RecursiveInsertionSort();
        int[] arr = new int[]{100};
        int[] output = new int[]{100};
        int[] temp = ris.insertionSort(arr, 1);
        List<Integer> list = new ArrayList<>();
        List<Integer> res = new ArrayList<>();
        for(int n : temp) {
            list.add(n);
        }
        for(int n : output) {
            res.add(n);
        }
        Assert.assertEquals(list, res);
    }
}
