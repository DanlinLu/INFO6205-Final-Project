package com.example;

public class RecursiveInsertionSort {
    public int binarySearch(int[] a, int item, int low, int high)
    {
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (item == a[mid])
                return mid + 1;
            else if (item > a[mid])
                low = mid + 1;
            else
                high = mid - 1;
        }
        return low;
    }

    public int[] insertionSort(int[] a, int n)
    {
        if(n <= 1){
            return a;
        }
        insertionSort(a, n-1);
        //TO-DO:
        //Hint 1 : find location where selected element should be inseretd
        //Hint 2 : Move all elements after location to create space
        
    }
}
